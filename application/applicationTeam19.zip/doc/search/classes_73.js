var searchData=
[
  ['setupdater',['SetUpdater',['../classSetUpdater.html',1,'']]]
];
