var searchData=
[
  ['record',['Record',['../classRecord.html',1,'Record'],['../classRecord.html#ae8ee53ffec6ff4dac9911517d47e86a5',1,'Record::Record()'],['../classRecord.html#af6b85f753bb8dfea3e29728490b3d2a3',1,'Record::Record(vector&lt; pair&lt; string, string &gt; &gt; entries)']]],
  ['recorditerator',['RecordIterator',['../classRecord.html#ae8a1c90a4d896429d087ccc1f205f9b7',1,'Record']]],
  ['recordtype',['RecordType',['../classTable.html#af8f9ec96ecaa35a2e65312b74ddfeae6',1,'Table']]],
  ['rename_5fcolumn',['rename_column',['../classTable.html#ac5c19a55c8527ee267360cd1332317bd',1,'Table']]],
  ['rowdoesnotexisterror',['RowDoesNotExistError',['../classRowDoesNotExistError.html',1,'']]]
];
