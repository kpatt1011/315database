var searchData=
[
  ['max',['max',['../classTable.html#abb7aff3403f246965d7557ab592110dd',1,'Table']]],
  ['merge',['merge',['../classDatabase.html#a50aa2c5fbadfc54f2e098809d8b889ca',1,'Database']]],
  ['min',['min',['../classTable.html#a2a4882f99726fba725314e2625ed37ae',1,'Table']]]
];
