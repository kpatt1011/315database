var searchData=
[
  ['undefined_5ftype',['undefined_type',['../classTable.html#af8f9ec96ecaa35a2e65312b74ddfeae6a0e9b8fc48315b1aa6736b0a6d1a5dd5c',1,'Table']]],
  ['update',['update',['../classDatabase.html#a16075d5f6abe6faaa9b33fdeb224fb1b',1,'Database']]]
];
