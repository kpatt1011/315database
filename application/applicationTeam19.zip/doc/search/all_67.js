var searchData=
[
  ['get',['get',['../classRecord.html#ad1aa2b6fcd1d4cf6900dc446b113fbeb',1,'Record']]]
];
