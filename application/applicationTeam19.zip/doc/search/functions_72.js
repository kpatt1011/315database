var searchData=
[
  ['record',['Record',['../classRecord.html#ae8ee53ffec6ff4dac9911517d47e86a5',1,'Record::Record()'],['../classRecord.html#af6b85f753bb8dfea3e29728490b3d2a3',1,'Record::Record(vector&lt; pair&lt; string, string &gt; &gt; entries)']]],
  ['rename_5fcolumn',['rename_column',['../classTable.html#ac5c19a55c8527ee267360cd1332317bd',1,'Table']]]
];
