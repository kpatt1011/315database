var searchData=
[
  ['invalidoperationerror',['InvalidOperationError',['../classInvalidOperationError.html',1,'']]],
  ['invalidtypeerror',['InvalidTypeError',['../classInvalidTypeError.html',1,'']]],
  ['ioerror',['IOError',['../classIOError.html',1,'']]]
];
