var searchData=
[
  ['querysyntaxerror',['QuerySyntaxError',['../classQuerySyntaxError.html',1,'']]]
];
