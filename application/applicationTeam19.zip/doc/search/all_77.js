var searchData=
[
  ['wherematcher',['WhereMatcher',['../classWhereMatcher.html',1,'']]]
];
