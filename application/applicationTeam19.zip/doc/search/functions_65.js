var searchData=
[
  ['end',['end',['../classRecord.html#a50ab91b0bb46a381cd3e3b297e4b9d9e',1,'Record::end()'],['../classTable.html#a43c8c8884f3ea7ef66c5de5234e5d93d',1,'Table::end()']]]
];
