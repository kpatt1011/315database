var searchData=
[
  ['query',['query',['../classDatabase.html#a0520f606f68e207ca972e1c84b625805',1,'Database']]],
  ['querysyntaxerror',['QuerySyntaxError',['../classQuerySyntaxError.html',1,'']]]
];
