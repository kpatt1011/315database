var searchData=
[
  ['last',['last',['../classTable.html#afb08a45913f50106dc16388579897134',1,'Table']]],
  ['load',['load',['../classDatabase.html#ab246df676fdc5e7a0968f659e819adfa',1,'Database']]]
];
