var searchData=
[
  ['recorditerator',['RecordIterator',['../classRecord.html#ae8a1c90a4d896429d087ccc1f205f9b7',1,'Record']]]
];
