var searchData=
[
  ['update',['update',['../classDatabase.html#a16075d5f6abe6faaa9b33fdeb224fb1b',1,'Database']]]
];
