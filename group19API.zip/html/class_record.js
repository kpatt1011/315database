var class_record =
[
    [ "Record", "class_record.html#ae7b14f7e3328b1a7675a57bdd13bbf86", null ],
    [ "~Record", "class_record.html#ad2ce1a99d866834ab53dedd788cb1ea6", null ],
    [ "get_entry", "class_record.html#a57fc3ee51989c4473c7932bf97fd619a", null ],
    [ "get_size", "class_record.html#a5816debfce246b6c0349a0ffe6d7a205", null ],
    [ "replace_entry", "class_record.html#a84df98c88860fc2251de7cae581795fa", null ]
];