var class_table =
[
    [ "Table", "class_table.html#a049f2e06391781ae255c6698869c4ad1", null ],
    [ "Table", "class_table.html#aaa7b76762c147f6fcc2e60c3ea5a24b9", null ],
    [ "add_column", "class_table.html#a13473421aa33bb685f2d9bcd618b044d", null ],
    [ "cross_join", "class_table.html#a91c3b362549e478dd07d07584765c69f", null ],
    [ "delete_column", "class_table.html#aeefd19d55dc64eeaecb178b07f71a7fb", null ],
    [ "entry_count", "class_table.html#a04102405af408ff40368546fc4d542fc", null ],
    [ "entry_max", "class_table.html#a8915502cc6468fdf299b179a15ad8b55", null ],
    [ "entry_min", "class_table.html#ae6bd2b3d7970477754c6045bb4e0f130", null ],
    [ "entry_sum", "class_table.html#a54b05026fa1e20aba8ff8dd5fb7012a9", null ],
    [ "get_columns", "class_table.html#ac6121a979a6174e625b21f973524ddcd", null ],
    [ "get_record_at", "class_table.html#ad701fba9dea544b0da3ae790154251da", null ],
    [ "get_size", "class_table.html#a3adee5d206107494e1ad602a435b4af3", null ],
    [ "insert_row", "class_table.html#abce2e0084e3366ce6bc9566e0c84cd8f", null ],
    [ "rename_column", "class_table.html#af56cbc68307d0b6d45204fe1d3491a83", null ]
];