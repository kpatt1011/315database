var class_database =
[
    [ "Database", "class_database.html#a4703c80e6969d33565ea340f768fdadf", null ],
    [ "~Database", "class_database.html#a84d399a2ad58d69daab9b05330e1316d", null ],
    [ "add_table", "class_database.html#ac6e9807456521575ae54e5d4314af995", null ],
    [ "drop_table", "class_database.html#a7c85efbb112bdabd4190abdb9005b39a", null ],
    [ "erase", "class_database.html#ab5d75308185ae2bb66423b7584054b0c", null ],
    [ "get_tables", "class_database.html#af16a10726b6455d10d94ae55ccedfd65", null ],
    [ "list_table_names", "class_database.html#a52798592a3c51abeba6613565b3edeef", null ],
    [ "query", "class_database.html#a84d18403d21da42baa9eb26eb8ebad6a", null ]
];